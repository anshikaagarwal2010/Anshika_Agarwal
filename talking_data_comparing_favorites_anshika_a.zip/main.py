#Talking Data Starter Code

#Part 2 Setting up the program
import pandas as pd
import matplotlib.pyplot as plt

pd.set_option('display.max_columns', None)
pd.set_option('max_colwidth', None)

movieData = pd.read_csv('./rotten_tomatoes_movies.csv')
favMovie = "Golmaal 3"
print("My favorite movie is "+ favMovie)



#Part 3 Investigate the data
#print(movieData)
#print(movieData.head())
#print(movieData["movie_title"])


#Part 4 Filter data
print("\nThe data for my favorite movie is:\n")

#Create a new variable to store your favorite movie information
favMovieBoolean_List=movieData["movie_title"]==favMovie
favMovieData=movieData.loc[favMovieBoolean_List]
print(favMovieData)



print("\n\n")

#Create a new variable to store a new data set with a certain genre

moviegenreBooleanList=movieData["genres"].str.contains("Comedy")
moviegenredata=movieData.loc[moviegenreBooleanList]


numOfMovies = moviegenredata.shape[0]

print("We will be comparing " + favMovie +
      " to other movies under the genre Comedy in the data set.\n")
print("There are " + str(numOfMovies) + " movies under the category Comedy.")

print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
input("Press enter to see more information about how " + favMovie +
      " compares to other movies in this genre.\n")

#Part 5 Describe data
#min
min = moviegenredata["audience_rating"].min()
print("The min audience rating of the data set is: " + str(min))
print(favMovie + " is rated 50 points higher than the lowest rated movie.")
print()

#find max
max = moviegenredata["audience_rating"].max() 
print("The max audience rating of the data set is: " + str(max))
print(favMovie + " is rated 50 points lower than the highest rated movie.")
print()

#find mean
mean = moviegenredata["audience_rating"].mean()
print("The mean audience rating of the data set is: " + str(mean))
print(favMovie + " is lower than the mean movie rating.")

#find median
median = moviegenredata["audience_rating"].median()
print("The median audience rating of the data set is: " + str(median))
print(favMovie + " is lower than the median movie rating.")

print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
input("Press enter to see data visualizations.\n")

#Part 6 Create graphs
#Create histogram
plt.hist(moviegenredata["audience_rating"], range=(0,100), bins =40)

#Adds labels and adjusts histogram
plt.grid(True)
plt.title("Comedy Movies Audience Rating")
plt.xlabel("Audience Rating")
plt.ylabel("Number of Comedy Movies")

#Prints interpretation of histogram
print("The histogram shows a roughly symmetric, mound-shaped    distribution centered between ratings of 40 and 80, with the absolute highest frequencypeaking around a rating of 70. Its most striking feature is a distinct, alternating 'comb-like' pattern across the topbins, suggesting audience rating biases toward specific numbers. Truly extreme low ratings (under 20) or high ratings (near 100) are notably rare." )

print()
#Show histogram
plt.show()
input("Press enter to see the next data visualization.\n")
plt.clf()

#Create scatterplot
plt.scatter(data=moviegenredata, 
            x="audience_rating", y="critic_rating")
#Adds labels and adjusts scatterplot
plt.grid(True)
plt.title("Audience Rating vs Critic Rating")
plt.xlabel("Audience Rating")
plt.ylabel("Critic Ratinng")
plt.xlim(0, 105)
plt.ylim(0, 105)

#Prints interpretation of scatterplot
print(
  "According to the scatter plot, there is a clear positive correlation between audience and critic ratings. While they generally agree that better movies get higher scores, the data points are still pretty scattered, meaning their opinions vary a lot. You can also spot some obvious outliers in the corners where they completely disagree, like movies that critics absolutely loved but audiences hated, and others where the crowd loved it but the critics totally trashed it")
print()


#Show scatterplot
plt.show()

print("\nThank you for reading through my data analysis!")
